<footer class="footer">
  <div class="container-fluid">
      <div class="row text-muted">
          <div class="col-6 text-start">
              <p class="mb-0">
                  <a class="text-muted" href="#" target="_blank"><strong>Kalil - VENDAS</strong></a> &copy;
              </p>
          </div>
          <div class="col-6 text-end">
            <ul class="list-inline">
                <li class="list-inline-item">
                    <a class="text-muted" href="#" target="_blank">Contato</a>
                </li>
            </ul>
          </div>
      </div>
  </div>
</footer>
